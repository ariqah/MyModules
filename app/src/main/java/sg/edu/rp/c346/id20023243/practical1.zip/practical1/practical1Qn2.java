package sg.edu.rp.c346.id20023243.practical1;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

public class practical1Qn2 extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_practical1_qn2);
    }
}